const Books = [
    {
        ISBN : '12345',
        title : 'Spring Microservices',
        author : 'Kim',
        price : 59.88,
        imgUrl : '',
        introduce :'Spring Books .... ..... .... '
    },
    {
        ISBN : '67890',
        title : 'React Programming',
        author : 'Park',
        price : 66.88,
        imgUrl : '',
        introduce : 'React Books .... ..... .... '
    },
    {
        ISBN : '38285',
        title : 'Angular Programming',
        author : 'JIM',
        price : 22.88,
        imgUrl : '',
        introduce :'Angular Books .... ..... .... '
    }



]

export default Books;