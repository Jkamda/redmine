import React, {Component} from 'react';

class Customer extends React.Component {

    static propsTypes = {
        
    }
    render(){
        const { id, name, orders} = this.props;

        return (
            <div className="customer">
                <h2>{id}</h2>
                <p>
                    <span>이름 : {name}</span><br/>
                    <span>주문 수량 : {orders.length }</span>
                </p>
            </div>

        );
    }

}

export default Customer;