import React, {Component} from 'react';
import SearchBar from './components/SearchBar';
import Books from './static_data/Books';
import BookList from './components/BookList';
import BookDetail from './components/BookDetail';
import { Segment, Grid } from 'semantic-ui-react';


class StateApp extends Component {

    constructor(props){
        super(props);
        this.state = {
            books: Books,
            selectedBook : Books[0] //바껴야될 데이터
        }
    }

    

    render(){

        return( 
            <div>
                <Segment>
                <SearchBar/>
                </Segment>
                <Grid columns={2} stackable>
                    <Grid.Column>
                        <BookList 
                            onBookSelect = {selectedBook => 
                                this.setState({selectedBook})}
                            books={this.state.books}
                            
                            />
                    </Grid.Column>
                    

                    
                    
                    <Grid.Column>
                        <BookDetail book={this.state.selectedBook}/>
                    </Grid.Column>
                </Grid>
            </div>
           

        );
    }
}

export default StateApp;