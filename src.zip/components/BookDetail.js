import React, {Component} from 'react';
import { Card } from 'semantic-ui-react';
class BookDetail extends Component {


    render(){

        return (
            <Card>
                <Card.Content>
                    <Card.Header> {this.props.book.title} </Card.Header>
                    <Card.Meta>{this.props.book.introduce}</Card.Meta>
                </Card.Content>
            </Card>
        )
    }
}

export default BookDetail;