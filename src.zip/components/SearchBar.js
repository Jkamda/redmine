import React, {Component} from 'react';
import { Input } from 'semantic-ui-react'

class SearchBar extends Component{
 
    render(){


        return (
            <Input icon={{ name: 'search', circular: true, link: true }} placeholder='Search...' />
        )
    }
}

export  default SearchBar; 