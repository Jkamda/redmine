import React, {Component} from 'react';
import BookListItem from './BookListItem';
import { Item } from 'semantic-ui-react';

class BookList extends Component {

    render(){
        const bookListItem = this.props.books.map(
            book=> {
                return (
                    <BookListItem 
                        onBookSelect = {this.props.onBookSelect} //By Pass BookListItem에게 
                        key= {book.ISBN}
                        book= {book}

                    />

                )
            }
        )
        return (
            <Item.Group divided link>
                {bookListItem}
            </Item.Group>
        )
    }
}

export default BookList;