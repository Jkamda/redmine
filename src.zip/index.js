import React from 'react';
import ReactDOM from 'react-dom';
import * as serviceWorker from './serviceWorker';
import StateApp from './StateApp';
import 'semantic-ui-css/semantic.min.css';

ReactDOM.render(
    <StateApp/>
    ,
    document.getElementById('root')
);

serviceWorker.unregister();
