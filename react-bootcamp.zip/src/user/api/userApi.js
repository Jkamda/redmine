import axios from 'axios';


function findAllUsers(){

    return axios.get('/user-api/users').then((response) => response.data );
}

function registerUser(user){

    return axios.post('/user-api/users', user);
}

export default {
    findAllUsers,
    registerUser
};
