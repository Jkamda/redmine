
import React, { Component } from 'react';
import { Container, Header, Divider, Grid, Button, Table, Icon } from 'semantic-ui-react';
import userApi from '../api/userApi';
import autobind from 'autobind-decorator';
import UserPop from '../component/UserPop';

@autobind
class UserList extends Component {
  //
  state = {
    users: [],
    userPopOpen : false,
  };

  constructor(props){
    super(props);

    //this을 할당한 다고 생각하면 된다.
    //this.reload=this.reload.bind(this);//bind => 명시적으로 this을 바인딩하겠다.
    //this.find=this.find.bind(this);
    

  }
  
  componentDidMount(){
    //render가 최초로 호출 된 다음에 호출된다.
    //api 조회 
    //this.setState({ users : users}); 똑같다면 생략 가능  -> this.setState({users});

    //promice 객체란 비동기에 대한 처리를 할 수 있는 객체.;

    userApi.findAllUsers().then((users) => this.setState({users}))
  }


  reload(){
    userApi.findAllUsers().then((users) => this.setState({users}))

  }

  openUserpop(){
    this.setState( {userPopOpen : true})
  }

  closeUserPop(){
    this.setState( {userPopOpen : false})
  }

  render() {

    //const users= this.state.users;
    //const address = this.state.address;

    const { users , userPopOpen } = this.state;
    console.log(users)

    return (
      <Container style={{ margin: '2em' }}>


        <UserPop 
          open={userPopOpen}
          onClose={this.closeUserPop}
        />

        <Header as='h1' content='사용자 목록' />
        <Divider />

        <Grid>
          <Grid.Row>
            <Grid.Column>
              <Button primary floated="right" onClick = {this.openUserpop}>등록</Button>
              <Button floated="right" onClick={this.reload}>새로고침</Button>
            </Grid.Column>
          </Grid.Row>
        </Grid>

        <Table celled>
          <Table.Header>
            <Table.Row textAlign="center">
              <Table.HeaderCell>이메일</Table.HeaderCell>
              <Table.HeaderCell>이름</Table.HeaderCell>
              <Table.HeaderCell>전화번호</Table.HeaderCell>
              <Table.HeaderCell>상세보기</Table.HeaderCell>
            </Table.Row>
          </Table.Header>

          <Table.Body>
            
            {

              users.length > 0 ?
              //js문법을 쓰기위해서 위에 {}을 넣는다.
              users.map( (user, index) => {
                return (
                <Table.Row key={index}>
                  <Table.Cell>{user.email}</Table.Cell>
                  <Table.Cell>{user.name}</Table.Cell>
                  <Table.Cell>{user.phone}</Table.Cell>
                  <Table.Cell textAlign='center'>
                    <Icon name="angle right" />
                  </Table.Cell>
                </Table.Row>
              )
            }) : 
            <Table.Row colSpan={4}>
              <Table.Cell>등록된 사용자가 없습니다.</Table.Cell>
            </Table.Row>
            }
          </Table.Body>
        </Table>

      </Container>
    )
  }
}

export default UserList;
