
import React, { Component } from 'react';
import { Modal, Form, Grid, Button } from 'semantic-ui-react';
import autobind from 'autobind-decorator';
import Protypes from 'prop-types';

import userApi from '../api/userApi';

@autobind
class UserPop extends Component {


  //개발모드로 사용할때만 사용함.
  static Protypes= {
    open: Protypes.bool,
    onClose: Protypes.func,
  }

  state = {
    name: '',
    email: '',
    phone: ''
  }

  register(){
    const { onClose} = this.props;
    const {name, email, phone} = this.state;
    const user ={
      name, email, phone
    }

    userApi.registerUser(user).then(
      () => {
          window.alert('등록 되었습니다.')
          onClose();
      }
    );
    
  }


  setEmail(e){
    this.setState({email: e.target.value });
  }

  setName(e){
    this.setState({name : e.target.value});
  }

  setPhone(e){
    this.setState({phone: e.target.value});
  }
  render() {


    const {open, onClose } = this.props;
    const {email, name, phone} = this.state;

    return (
      <Modal
        open={open}
        onClose={onClose}
      >
        <Modal.Content>
          <Form>
            <Form.Field>
              <label>이메일</label>
              <input placeholder='이메일' value={email} onChange={this.setEmail} />
            </Form.Field>

            <Form.Field>
              <label>이름</label>
              <input placeholder="이름" value={name} onChange={this.setName} />
            </Form.Field>

            <Form.Field>
              <label>전화번호</label>
              <input placeholder="전화번호" value={phone} onChange={this.setPhone} />
            </Form.Field>

            <Grid>
              <Grid.Row>
                <Grid.Column>
                  <Button primary floated="right" onClick={this.register}>저장</Button>
                  <Button floated="right" onClick={onClose}>취소</Button>
                </Grid.Column>
              </Grid.Row>
            </Grid>
          </Form>
        </Modal.Content>
      </Modal>
    )
  }
}

export default UserPop;
