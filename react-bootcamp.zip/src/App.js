import React from 'react';
import HelloWorld from './helleworld/HelloWorld';
import UserList from './user/component/UserList';
import UserPop from './design/UserPop';
import UserDetail from './design/UserDetail';
import UserAddressPop from './design/UserAddressPop';


// class App extends Component {
//     render() {
//         return (
//             <div>
//                  <UserDetail />
//             </div>
//         );
//     }
// }

// 소괄호로 하면 단일 라인 + 자동으로 리턴 해준다.
const App = () => (
    <div>
        <UserList />
    </div>
);


//중괄호로 하면 리턴도 따로 해줘야함.
// const App = () => {
//     return (<UserDetail/>);
// }

export default App;
