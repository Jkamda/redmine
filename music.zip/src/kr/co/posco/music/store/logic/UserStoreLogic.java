package kr.co.posco.music.store.logic;

import org.springframework.stereotype.Repository;

import kr.co.posco.music.domain.User;
import kr.co.posco.music.store.UserStore;
import kr.co.posco.music.store.repository.MusicPlayRepository;

@Repository
public class UserStoreLogic implements UserStore {
	//
	private MusicPlayRepository repository;
	
	public UserStoreLogic() {
		//
		repository = MusicPlayRepository.createInstance();
	}
	
	@Override
	public boolean create(User user) {
		//
		repository.createUser(user);
		return true;
	}

	@Override
	public User read(String id) {
		//
		return repository.readUser(id);
	}

}
