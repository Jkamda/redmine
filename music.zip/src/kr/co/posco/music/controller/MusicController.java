package kr.co.posco.music.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import kr.co.posco.music.domain.Music;
import kr.co.posco.music.service.MusicService;

@Controller
public class MusicController {

	@Autowired
	private MusicService service;

	@RequestMapping("/")
	public String main() {
		return "redirect:list";
	}

	@RequestMapping("/list")
	public ModelAndView showMusicChart() {
		List<Music> list = service.findAll();
		ModelAndView modelAndView = new ModelAndView("list");
		modelAndView.addObject("musicList", list);
		return modelAndView;
	}

	@RequestMapping("/searchByName")
	public ModelAndView searchByName(@RequestParam("musicName") String name) {
		List<Music> list = service.findByName(name);
		ModelAndView modelAndView = new ModelAndView("list");
		modelAndView.addObject("musicList", list);
		return modelAndView;
	}

	@RequestMapping("/detail")
	public ModelAndView showDetail(@RequestParam("musicId") int id) {
		ModelAndView modelAndView = new ModelAndView("detail");
		modelAndView.addObject("music", service.find(id));
		return modelAndView;
	}
}
