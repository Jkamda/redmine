package kr.co.posco.music.service.logic;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import kr.co.posco.music.domain.User;
import kr.co.posco.music.service.UserService;
import kr.co.posco.music.store.UserStore;

@Service
public class UserServiceLogic implements UserService {

	@Autowired
	private UserStore store;

	@Override
	public User login(User user) {
		//
		User readedUser = null;
		if (validate(user)) {
			readedUser = store.read(user.getLoginId());
		}
		return readedUser;
	}

	@Override
	public boolean register(User user) {
		//
		if (!validate(user)) {
			return false;
		} else if (store.read(user.getLoginId()) != null) {
			return false;
		}
		return store.create(user);
	}

	@Override
	public User find(String loginId) {
		//
		return store.read(loginId);
	}

	private boolean validate(User user) {
		//
		if (user == null) {
			throw new RuntimeException("사용자 정보가 없습니다.");
		} else if (user.getLoginId() == null || user.getLoginId().isEmpty()) {
			throw new RuntimeException("ID가 존재하지 않습니다.");
		} else if (user.getPassword() == null || user.getPassword().isEmpty()) {
			throw new RuntimeException("비밀번호가 일치하지 않습니다.");
		}
		return true;
	}

}
