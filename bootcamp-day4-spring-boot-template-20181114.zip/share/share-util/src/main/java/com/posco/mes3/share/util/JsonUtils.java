package com.posco.mes3.share.util;

public class JsonUtils {
    //
    private String name;
}
