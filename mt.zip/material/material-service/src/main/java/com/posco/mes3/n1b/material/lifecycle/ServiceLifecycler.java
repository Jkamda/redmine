package com.posco.mes3.n1b.material.lifecycle;

import org.springframework.stereotype.Component;

import com.posco.mes3.n1b.material.logic.RawMaterialLogic;
import com.posco.mes3.n1b.material.spec.RawMaterialService;

@Component
public class ServiceLifecycler implements ServiceLifecylce{
	
	private StoreLifecycle storeLifecycle;
	
	public ServiceLifecycler(StoreLifecycle storeLifecycle) {
		this.storeLifecycle = storeLifecycle;
	}

	public RawMaterialService requestRawMeMaterialService() {
		// TODO Auto-generated method stub
		return new RawMaterialLogic(this.storeLifecycle);
	}

}
