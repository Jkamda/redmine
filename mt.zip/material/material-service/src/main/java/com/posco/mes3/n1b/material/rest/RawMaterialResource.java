package com.posco.mes3.n1b.material.rest;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.posco.mes3.n1b.material.entity.RawMaterial;
import com.posco.mes3.n1b.material.lifecycle.ServiceLifecylce;
import com.posco.mes3.n1b.material.spec.RawMaterialService;

//n11 : RawMaterialService 를 노출시켜준다고 했으니...
@RestController
public class RawMaterialResource implements RawMaterialService{
	//서비스한테 전달을 해줄거다.
	private RawMaterialService rawMaterialService;

	//n14
	public RawMaterialResource(ServiceLifecylce serviceLifecycle) {
		this.rawMaterialService= serviceLifecycle.requestRawMeMaterialService();
	}
	
	@PostMapping(value= {"", "/"} ) //경로는 두 개 줄때,...{}안에 ... //RequestBody로 받을 것이다... 바인딩에 관한 어놑이션. 
	public String registerRawMaterial(@RequestBody RawMaterial rawMaterial) {
		// TODO Auto-generated method stub
		return rawMaterialService.registerRawMaterial(rawMaterial);
	}

	@GetMapping(value="/{id}")
	public RawMaterial findRowMaterial(@PathVariable(value="id") String id) {
		// TODO Auto-generated method stub
		return rawMaterialService.findRowMaterial(id);
	}

	@DeleteMapping(value="/{id}")
	public void removeRawMaterial(@PathVariable(value="id") String id) {
		// TODO Auto-generated method stub
		rawMaterialService.removeRawMaterial(id);
	}
	
}
