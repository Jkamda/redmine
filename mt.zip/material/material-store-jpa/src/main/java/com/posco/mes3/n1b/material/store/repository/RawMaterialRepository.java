package com.posco.mes3.n1b.material.store.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.posco.mes3.n1b.material.entity.RawMaterial;
import com.posco.mes3.n1b.material.store.jpo.RawMaterialJpo;

//n9
public interface RawMaterialRepository extends JpaRepository<RawMaterialJpo, String >{
//	public RawMaterialJpo findByName(String name);//이거 JPA 규칙있는데 그건 DOC 확인해
//
//	public List<RawMaterial> findAllOrderByNameAsc(); // 예약어가 다 존재함. 오름차순으로 정렬됨.
	

}
