package com.posco.mes3.n1b.material.store.jpo;

import javax.persistence.Entity;
import javax.persistence.Id;

import com.posco.mes3.n1b.material.entity.RawMaterial;
import com.posco.mes3.share.domain.Dimension;

//n8
@Entity // persistence.Entity을 쓸거임.
public class RawMaterialJpo {
	//jpo java persistance object domain과 store의 매핑
	//테이블과 매핑이 되는 클래스... => JPO에서 쓸수있도록 Entitiy를 ...
	
	@Id //Id를 쓰면 pk가 된다.
	private String id;
	
	private String name;
	
	
//	private Dimension dimension;//우리가 정의한 것이라서 두가지 방법이있다. 디맨젼을 폭,길이. .. 따로 젖아할꺼야. 한번에 저장할꺼냐.
	//Json으로 저장하는 방법으로 구현ㅇ르 일단...
	
	private String dimensionJson;
	
	
	//생성자 반드시 필요
	public RawMaterialJpo() {
		//빈 생성자, 
	}
	
	//도메인 객체를 받아주늣  생성자
	//필드
	public RawMaterialJpo(RawMaterial rawMaterial) {
		//속성들의 카피일 뿐.
		//ㅣ도메인 객체를 받음 JPO로 저장을 할꺼임 도메인. JPO가 도에민 알아ㅑ함.
		this.id= rawMaterial.getId();
		this.name=rawMaterial.getName();
		//폭, 길이 , 두께 를 json 포맷으로 저장하겠다는 뜻.
		this.dimensionJson = rawMaterial.getDimension().toJson();
	}
	
	//필수 
	//
	public RawMaterial toDomain() {
		//반대로 반환할때는..
		RawMaterial rawMaterial = new RawMaterial();
		
		rawMaterial.setId(this.id);
		rawMaterial.setName(this.name);
		rawMaterial.setDimension(Dimension.fromJson(this.dimensionJson));
		return rawMaterial;
	}
	
	//그러면 도메인에 도메인객체에 Entity을 달아줘도되지안ㅇㅎ므?
	// 도메인 객체는 변하지않는다가 핵심. 기술이 바뀔때 따라간다가 중요함.. 도메인에는 기술과 관련된 그 어떤 어노테이션이 없다.
	//그걸 지키기 위해서 ....분리해놓은거임.

}
