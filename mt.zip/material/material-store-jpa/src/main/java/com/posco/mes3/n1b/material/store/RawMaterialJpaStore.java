package com.posco.mes3.n1b.material.store;

import java.util.NoSuchElementException;
import java.util.Optional;

import org.springframework.stereotype.Repository;

import com.posco.mes3.n1b.material.entity.RawMaterial;
import com.posco.mes3.n1b.material.store.jpo.RawMaterialJpo;
import com.posco.mes3.n1b.material.store.repository.RawMaterialRepository;

//n7 => store 밑에....
//로직이 스토어한테 파라미터 받아서 해주는데.. 똑같이 전달을 해주느것이다.
@Repository
public class RawMaterialJpaStore implements RawMaterialStore {
	//n10
	private RawMaterialRepository rawMaterialRepository;
	
	@Override
	public void createRawMaterial(RawMaterial rawMaterial) {
		// TODO Auto-generated method stub
		RawMaterialJpo jpo= new RawMaterialJpo(rawMaterial);
		this.rawMaterialRepository.save(jpo);
		//this.rawMaterialRepository.save(new RawMaterialJpo(rawMaterial));
		
	}

	@Override
	public RawMaterial retrieveRawMaterial(String id) {
		// TODO Auto-generated method stub
		Optional<RawMaterialJpo> jpo = this.rawMaterialRepository.findById(id);// RawMaterial 의 id 이면서 Jpo의 id 이기도함.
		if(!jpo.isPresent()) {
			//isPresent 있으면...
			throw new NoSuchElementException(String.format("RawMaterial(%s) is not found.", id));
		}
		return jpo.get().toDomain();//jpo에 필수로 구현한 toDomain 여기서 쓰임.. 저장할땐 생성자로, 조회했을땐 toDomin으로 사용.
	}

	@Override
	public void deleteRawMaterial(String id) {
		// TODO Auto-generated method stub
		this.rawMaterialRepository.deleteById(id);
		
	}

	@Override
	public void deleteRawMaterial(RawMaterial rawMaterial) {
		// TODO Auto-generated method stub
		
	}

}
