package com.posco.mes3.n1b.material.lifecycle;

import org.springframework.stereotype.Component;

import com.posco.mes3.n1b.material.store.RawMaterialStore;

//빈으로 관리되기위해서 compoennt을 달아준다.
@Component //스프링빈으로 관리 ...
public class StoreLifecycler implements StoreLifecycle {

	//
	private RawMaterialStore rawMeterialStore;
	
	//생서자 만들고 , 
	public StoreLifecycler(RawMaterialStore rawMaterialStore) {
		// TODO Auto-generated constructor stub
		this.rawMeterialStore=rawMaterialStore;
	}
	
	@Override
	public RawMaterialStore requestRowMaterialStore() {
		// TODO Auto-generated method stub
		return this.rawMeterialStore;
	}

}
