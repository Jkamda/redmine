package com.posco.mes3.n1b.material.entity;

import com.posco.mes3.share.domain.Dimension;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RawMaterial {
	//
	
	//n1
	private String id;
	private String name;
	private Dimension dimension;
	
	
	
	
}
