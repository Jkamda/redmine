package com.posco.mes3.n1b.material.lifecycle;

import com.posco.mes3.n1b.material.spec.RawMaterialService;

public interface ServiceLifecylce {

	RawMaterialService requestRawMeMaterialService();
}
