package com.posco.mes3.n1b.material.lifecycle;

import org.springframework.stereotype.Component;

import com.posco.mes3.n1b.material.lifecycle.ServiceLifecycle;
import com.posco.mes3.n1b.material.lifecycle.StoreLifecycle;
import com.posco.mes3.n1b.material.logic.SlabLogic;
import com.posco.mes3.n1b.material.spec.SlabService;

@Component
public class ServiceLifecycler implements ServiceLifecycle {

	
	private final StoreLifecycle storeLifecycle;
	
	
	public ServiceLifecycler(StoreLifecycle storeLifecycle) {
		this.storeLifecycle=storeLifecycle;
	}
	
	@Override
	public SlabService requestSlabService() {
		// TODO Auto-generated method stub
		return new SlabLogic(storeLifecycle);
	}

}
