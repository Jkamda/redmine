package com.posco.mes3.n1b.material.rest;

import com.google.gson.Gson;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.MOCK)
@AutoConfigureMockMvc
public class SlabResourceTest {
    //
//    @Autowired
//    private MockMvc mvc;
//
//    @Before
//    public void before() {
//        //
//    }
//
//    @Test
//    public void registerSlab() throws Exception {
//        //
//        Slab slab = Slab.sample();
//        MvcResult result = mvc.perform(MockMvcRequestBuilders
//                .post("/")
//                .content((new Gson()).toJson(slab))
//                .contentType(MediaType.APPLICATION_JSON))
//                .andReturn();
//        System.out.println(result);
//    }

    @Test
    public void test() {

    }

}
