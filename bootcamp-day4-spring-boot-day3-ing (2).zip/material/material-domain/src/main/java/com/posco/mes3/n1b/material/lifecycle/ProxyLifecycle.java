package com.posco.mes3.n1b.material.lifecycle;

public interface ProxyLifecycle {

}
