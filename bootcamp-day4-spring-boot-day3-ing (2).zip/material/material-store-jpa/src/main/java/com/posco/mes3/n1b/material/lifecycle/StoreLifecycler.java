package com.posco.mes3.n1b.material.lifecycle;

import org.springframework.stereotype.Component;

import com.posco.mes3.n1b.material.store.SlabStore;


@Component
public class StoreLifecycler implements StoreLifecycle {

	
	private final SlabStore slabStore;
	
	 public StoreLifecycler(SlabStore slabStore) {
		// TODO Auto-generated constructor stub
		 this.slabStore=slabStore;
	}
	@Override
	public SlabStore requestSlabStore() {
		// TODO Auto-generated method stub
		return null;
	}
	
}
