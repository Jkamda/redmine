package com.posco.mes3.n1b.material.store.jpo;


import javax.persistence.Entity;
import javax.persistence.Id;


import com.posco.mes3.n1b.material.entity.Dimension;
import com.posco.mes3.n1b.material.entity.Slab;

@Entity
public class SlabJpo {
	//
	@Id
	private String id;
	private double thickness;
	private String dimensionJson;
	
	public SlabJpo(Slab slab) {
		//
		this.id = slab.getId();
		this.thickness = slab.getDimension().getThickiness();
		this.dimensionJson = slab.getDimension().toJson();
		System.out.println(this.id);
		System.out.println(this.thickness);
		System.out.println(this.dimensionJson);
		
		
	}
	
	public Slab toDomain() {
		//
		Slab slab = new Slab(this.id);
		slab.setDimension(Dimension.fromJson(dimensionJson));
		return slab;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public double getThickness() {
		return thickness;
	}

	public void setThickness(double thickness) {
		this.thickness = thickness;
	}

	public String getDimensionJson() {
		return dimensionJson;
	}

	public void setDimensionJson(String dimensionJson) {
		this.dimensionJson = dimensionJson;
	}
	
	
}












