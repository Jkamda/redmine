package com.posco.mes3.n1b.material.store.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.posco.mes3.n1b.material.store.jpo.SlabJpo;

public interface SlabRepository extends JpaRepository<SlabJpo, String> {
	
}
