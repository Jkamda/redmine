package com.posco.mes3.n1b.material.store;

import java.util.NoSuchElementException;
import java.util.Optional;

import org.springframework.stereotype.Repository;

import com.posco.mes3.n1b.material.entity.Slab;
import com.posco.mes3.n1b.material.store.jpo.SlabJpo;
import com.posco.mes3.n1b.material.store.repository.SlabRepository;


@Repository
public class SlabJpoStore implements SlabStore {

	
	private final SlabRepository slabRepository;

	public SlabJpoStore(SlabRepository slabRepository) {
		// TODO Auto-generated constructor stub
		this.slabRepository=slabRepository;
	}
	
	@Override
	public void create(Slab slab) {
		// TODO Auto-generated method stub
		this.slabRepository.save(new SlabJpo(slab));
		
	}

	@Override
	public Slab retrieve(String id) {
		// TODO Auto-generated method stub
		Optional<SlabJpo> slabJpo = this.slabRepository.findById(id);
		if(!slabJpo.isPresent()) {
			throw new NoSuchElementException(String.format("Slab(%s) is not found."));
		}
		return slabJpo.get().toDomain();
	}

	@Override
	public void update(Slab slab) {
		// TODO Auto-generated method stub
		this.slabRepository.save(new SlabJpo(slab));
		
	}

	@Override
	public void delete(Slab slab) {
		// TODO Auto-generated method stub
		this.slabRepository.delete(new SlabJpo(slab));
		
	}

	
	//사용하지 않는 코드는 형상관리에 넣지 않는것이 좋다.
//	public void elete(String id) {
//		this.slabRepository.deleteById(id);
//	}
}
