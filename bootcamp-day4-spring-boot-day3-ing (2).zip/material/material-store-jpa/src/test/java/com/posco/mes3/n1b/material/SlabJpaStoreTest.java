package com.posco.mes3.n1b.material;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = MaterialTestApp.class)
@DirtiesContext(classMode= DirtiesContext.ClassMode.AFTER_EACH_TEST_METHOD)
public class SlabJpaStoreTest {
    //
//    @Autowired
//    SlabStore slabStore;
//
//    private Slab slab;
//
//    @Before
//    public void before() {
//        //
//        slab = Slab.sample();
//    }
//
//    @Test
//    public void testCreate() {
//        //
//        slabStore.create(slab);
//
//        boolean isExists = slabStore.existsById(slab.getId());
//        Assert.assertTrue(isExists);
//    }
//
//    @Test
//    public void testModify() {
//        //
//        slab.setName("ModifedSlab#1");
//        slabStore.update(slab);
//
//        Slab foundSlab = slabStore.retrieve(slab.getId());
//        Assert.assertEquals(slab.getName(), foundSlab.getName());
//    }

    @Test
    public void test() {
    }

}
