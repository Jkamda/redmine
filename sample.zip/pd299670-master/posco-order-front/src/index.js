
import React from 'react';
import ReactDOM from 'react-dom';

import App from './App';
import OrderList from './order_simple/OrderList';


ReactDOM.render(
    <App />, 
    document.getElementById('root'
));
