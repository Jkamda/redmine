import React, {Component} from 'react';
import { Container, Header, Divider, Grid, Button, Table, Icon } from 'semantic-ui-react';
import userApi from './userApi';

class OrderDetail extends Component {

    constructor(){
        super();
        this.state= {
          items: [
          
          ],
        }
    }
    
    componentDidMount() {
        this.findAllOrders();
    }

    findAllOrders() {

        userApi.findOrder (this.props.params.orderNo)
            .then((order) => {this.setState({items: order});
        });
    }

    render() {

        const { items=[] } = this.state;
        if (items.length <= 0) {
            return null;
        }

        return (
            <Container style={{ margin: '2em' }}>
                <Header as='h1' content='주문 상세' />
                <Divider />
            

                <Table celled>
                    <Table.Header>
                        <Table.Row textAlign="center">
                            <Table.HeaderCell>주문 상품</Table.HeaderCell>
                            <Table.HeaderCell>가격</Table.HeaderCell>
                            <Table.HeaderCell>수량</Table.HeaderCell>
                            <Table.HeaderCell>합계 금액</Table.HeaderCell>
                        </Table.Row>
                    </Table.Header>

                    <Table.Body>
                    {
                        items.items.map ((item) => {

                            return (
                                <Table.Row >
                                    <Table.Cell>{item.product.productName}</Table.Cell>
                                    <Table.Cell>{item.price}</Table.Cell>
                                    <Table.Cell>{item.quantity}</Table.Cell>
                                    <Table.Cell>{item.total.value}</Table.Cell>
                                </Table.Row>
                            )
                        })
                            
                    }
                    </Table.Body>

                </Table>
            </Container>
        )
    }
}

export default OrderDetail;