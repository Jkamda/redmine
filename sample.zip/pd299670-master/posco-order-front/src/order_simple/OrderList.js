
import React, { Component } from 'react';
import { Container, Header, Divider, Grid, Button, Table, Icon } from 'semantic-ui-react';
import userApi from './userApi';
import { Link } from 'react-router-dom';

class OrderList extends Component {
  //
  constructor(){
      super();
      this.state= {
        orders: [
        
        ],
      }
  }

  componentDidMount() {
    this.findAllOrders();
  }

  onConfirm() {
    this.findAllOrders();
  }

  findAllOrders() {
    userApi.findAllOrders()
    .then((order) => {
        this.setState({orders: order});
    });
  }

  handleRowClick(orderNo) {
    console.log (this.props);

    const { history } = this.props;
    this.props.router.push(`view/simple/orders/${orderNo}`);
  }

  render() {

    const { orders=[] } = this.state;
    

    if (orders.length <= 0) {
        return null;
    }
   
    let myDate, myProduct, totalPrice;

    return (
      <Container style={{ margin: '2em' }}>
        <Header as='h1' content='주문 목록' />
        <Divider />

        <Table celled>
          <Table.Header>
            <Table.Row textAlign="center">
              <Table.HeaderCell>주문 일시</Table.HeaderCell>
              <Table.HeaderCell>주문 상품</Table.HeaderCell>
              <Table.HeaderCell>결재 금액</Table.HeaderCell>
            </Table.Row>
          </Table.Header>

          <Table.Body>
              {
                Array.isArray(orders) && orders.length > 0 ? 
                orders.map((order) => 
                    {
                        const { items=[] } = order;
                        myDate = order.time;
                        totalPrice = order.total.value;
                        console.log(totalPrice);
                        //console.log(myDate);
                        return items.map((pro) => {
                            const { product=[] } = pro;
                            myProduct = product;     
                            
                            return (
                                <Table.Row onClick={this.handleRowClick.bind(this, order.orderNo)}>
                                    <Table.Cell>{Date(myDate)}</Table.Cell>
                                    <Table.Cell>{myProduct.productName}</Table.Cell>
                                    <Table.Cell>{totalPrice}</Table.Cell>
                                </Table.Row>
                            )
                        })
                    }
                )
                :     
                    <Table.Row>
                        <Table.Cell textAlign='center'>No registered orders</Table.Cell>
                    </Table.Row>
                }
          </Table.Body>
        </Table>
      </Container>
    )}
}

export default OrderList;
