import axios from 'axios';

function findAllOrders() {
    return axios.get('/order/orders')
        .then((response) => response.data); // async callback
}

function findOrder(orderNo) {
    return axios.get('/order/' + orderNo) 
        .then((response) => response.data);
}

export default {
    findAllOrders, 
    findOrder,
};