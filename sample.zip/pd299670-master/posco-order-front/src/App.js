
import React from 'react';
import { browserHistory } from 'react-router';
import Routes from './Routes';
const App = () => (
    <Routes history={browserHistory} />
);

export default App;
