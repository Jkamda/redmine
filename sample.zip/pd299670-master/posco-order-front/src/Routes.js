
import React  from 'react';
import { Router, Route, IndexRoute, IndexRedirect } from 'react-router';

import OrderList from './order_simple/OrderList';
import OrderDetail from './order_simple/OrderDetail';

const Routes = ({ history }) => (
  <Router history={history} onUpdate={() => console.log('url', window.location)}>
    <Route path={`/`}  >
      <IndexRedirect to="view/simple/orders"/>
      <Route path="view/simple/orders">
        <IndexRoute component={OrderList} />
        <Route path=":orderNo" component={OrderDetail}/>
      </Route>
    </Route>
  </Router>
);

export default Routes;
