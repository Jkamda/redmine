
const webpack = require('webpack');
const webpackMerge = require('webpack-merge');
const path = require('path');
const CopyWebpackPlugin = require('copy-webpack-plugin');

const buildCommon = require('./webpack.common.builder.js');


function build({ entry, additionalExternals }, { proxy, externalResources }) {
  //
  const config = {

    devtool: '#cheap-module-eval-source-map',

    output: {
      path: path.join(process.cwd(), './dist'),
      filename: '[name][hash].js'
    },

    module: {
      loaders: [
        {
          test: /\.js?$/,
          exclude: /(node_modules)/,
          loaders: ['react-hot-loader/webpack']
        },
        {
          test: /\.js?$/,
          exclude: /(node_modules)/,
          loader: 'babel-loader',
          query: {
            presets: ['env', 'stage-2', 'react'],
            compact: false
          }
        },
      ],
    },

    plugins: [
      new webpack.DefinePlugin({
        'process.env': {
          NODE_ENV: JSON.stringify('development'),
        },
      }),
      new webpack.HotModuleReplacementPlugin(),
    ],

    devServer: {
      historyApiFallback: true,
      stats: 'minimal',
      inline: true,
      hot: true,
      headers: { 'Access-Control-Allow-Origin': '*' },
    }
  };


  if (proxy && typeof proxy === 'object') {
    config.devServer.proxy = proxy;
  }
  console.log(proxy);
  console.log(config.devServer);

  return webpackMerge(buildCommon({ entry, additionalExternals }), config);
}

module.exports = build;
