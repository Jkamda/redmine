
const buildDev = require('./webpack.devServer.builder.js');


const commonOptions = {
  entry: {
    'vendor': './src/vendor.js',
    'app': './src/index.js',
  },
  additionalExternals: {},
};

const devOptions = {
  proxy: {
    '/order/**': {
      target: 'http://localhost:8080',      // for local
      secure: false,
    },
  },
};

module.exports = buildDev(commonOptions, devOptions);
