
const webpack = require('webpack');
const webpackMerge = require('webpack-merge');
const rimraf = require('rimraf');
const path = require('path');
const CopyWebpackPlugin = require('copy-webpack-plugin');

const buildCommon = require('./webpack.common.builder.js');

const constant = {
  WORK_DIR: 'app',
  OUTPUT_PATH: path.join(process.cwd(), '.', 'dist', 'app'),
};


function build({ entry, additionalExternals }, {}) {
  //
  rimraf.sync(constant.OUTPUT_PATH);

  const config = {
    output: {
      path: constant.OUTPUT_PATH,
      publicPath: '/common/metro/',
      filename: '[name].[hash].js',
      libraryTarget: 'window',
    },

    devtool: '#cheap-module-eval-source-map',

    module: {
      loaders: [
        {
          test: /\.js?$/,
          exclude: /(node_modules)/,
          loader: 'babel-loader',
          query: {
            presets: ['env', 'stage-2', 'react'],
            compact: false
          }
        },
      ],
    },

    plugins: [
      new webpack.DefinePlugin({
        'process.env': {
          NODE_ENV: JSON.stringify('development'),
        }
      }),
    ],
  };


  return webpackMerge(buildCommon({ entry, additionalExternals }), config);
}

module.exports = build;
