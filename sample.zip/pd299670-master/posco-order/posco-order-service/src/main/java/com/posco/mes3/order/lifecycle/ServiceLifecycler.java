package com.posco.mes3.order.lifecycle;

import org.springframework.stereotype.Component;

import com.posco.mes3.order.domain.lifecycle.ServiceLifecycle;
import com.posco.mes3.order.domain.lifecycle.StoreLifecycle;
import com.posco.mes3.order.domain.logic.OrderLogic;
import com.posco.mes3.order.domain.spec.OrderService;

@Component
public class ServiceLifecycler implements ServiceLifecycle {

	private final StoreLifecycle storelc;
	
	public ServiceLifecycler (StoreLifecycle slc) {
		this.storelc = slc;
	}
	
	public OrderService requestOrderService() {
		return new OrderLogic(storelc);
	}

}
