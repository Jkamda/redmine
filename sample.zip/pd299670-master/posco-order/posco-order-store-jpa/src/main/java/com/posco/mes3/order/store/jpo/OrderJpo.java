package com.posco.mes3.order.store.jpo;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

import javax.persistence.Entity;
import javax.persistence.Id;

import com.google.gson.Gson;
import com.posco.mes3.order.domain.entity.Order;
import com.posco.mes3.order.domain.entity.OrderItem;

import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
public class OrderJpo {

	@Id
	private String orderNo;
    private String userId;
    private long time;

    private String items;
    //private List<OrderItem> items;
    
    public OrderJpo() {}
    
    public OrderJpo(Order order) {
    	this.orderNo = order.getOrderNo();
    	this.userId = order.getUserId();
    	this.time = order.getTime();
    	this.items = stringify(order.getItems());
    }
    
    public Order toDomain() {
    	Order order = new Order(this.orderNo, this.userId);
    	order.setTime(this.time);
    	
    	Gson gson = new Gson();
    	OrderItem[] list = gson.fromJson(this.items, OrderItem[].class);
    	List<OrderItem> itemList = Arrays.asList(list);

    	order.setItems(itemList);
    	return order;
    }
    
    public static List<Order> toDomains(Iterable<OrderJpo> jpos) {
		/* @formatter:off */
		return StreamSupport.stream(jpos.spliterator(), false).map(OrderJpo::toDomain).collect(Collectors.toList());
		/* @formatter:on */
	}
    
    public String stringify (List<OrderItem> items) {
    	Gson gson = new Gson();
    	return gson.toJson(items);
    }
}
