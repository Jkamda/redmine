package com.posco.mes3.order.store;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;

import org.springframework.stereotype.Repository;

import com.posco.mes3.order.domain.entity.Order;
import com.posco.mes3.order.domain.store.OrderStore;
import com.posco.mes3.order.store.jpo.OrderJpo;
import com.posco.mes3.order.store.repository.OrderRepository;

@Repository
public class OrderJpaStore implements OrderStore {

	private final OrderRepository repo;
	
	public OrderJpaStore(OrderRepository repo) {
		this.repo = repo;
	}
	
	@Override
	public void createOrder(Order order) {
		repo.save(new OrderJpo(order));

	}

	@Override
	public Order retrieve(String orderNo) {
		Optional<OrderJpo> orderJpo = repo.findById(orderNo);
		if (!orderJpo.isPresent()) {
			throw new NoSuchElementException("");
		}
		return orderJpo.get().toDomain();
	}

	@Override
	public List<Order> retrieveAllByUserId(String userId) {
		return OrderJpo.toDomains(repo.findByUserId(userId));
	}

	@Override
	public List<Order> retrieveAll() {
		return OrderJpo.toDomains(repo.findAll());
	}

}
