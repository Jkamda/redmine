package com.posco.mes3.order.store.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.posco.mes3.order.store.jpo.OrderJpo;

public interface OrderRepository extends JpaRepository<OrderJpo, String> {
	List<OrderJpo> findByUserId(String userId);
}
