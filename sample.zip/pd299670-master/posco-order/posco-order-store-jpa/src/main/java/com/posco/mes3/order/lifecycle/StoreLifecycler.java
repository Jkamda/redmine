package com.posco.mes3.order.lifecycle;

import org.springframework.stereotype.Component;

import com.posco.mes3.order.domain.lifecycle.StoreLifecycle;
import com.posco.mes3.order.domain.store.OrderStore;

@Component
public class StoreLifecycler implements StoreLifecycle {

	private final OrderStore orderStore;
	
	public StoreLifecycler (OrderStore orderStore) {
		this.orderStore = orderStore;
	}
	
	@Override
	public OrderStore requestOrderStore() {
		return orderStore;
	}

}
