package com.posco.mes3.order;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExecApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExecApplication.class, args);
	}
}
