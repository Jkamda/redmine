package com.posco.mes3.order.domain.logic;

import java.util.List;

import com.posco.mes3.order.domain.entity.Order;
import com.posco.mes3.order.domain.lifecycle.StoreLifecycle;
import com.posco.mes3.order.domain.spec.OrderService;
import com.posco.mes3.order.domain.store.OrderStore;

public class OrderLogic implements OrderService {
    //
    private final OrderStore orderStore;

    public OrderLogic(StoreLifecycle storeLifecycle) {
        //
        this.orderStore = storeLifecycle.requestOrderStore();
    }

    public String registerOrder(Order order) {
        //
        orderStore.createOrder(order);
        return order.getOrderNo();
    }

    public Order findOrder(String orderNo) {
        //
        return orderStore.retrieve(orderNo);
    }

    public List<Order> findOrdersByUserId(String userId) {
        //
        return orderStore.retrieveAllByUserId(userId);
    }
    
    public List<Order> findAll() {
    	return orderStore.retrieveAll();
    }
}
