package com.posco.mes3.order.domain.entity;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import com.google.gson.Gson;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Order {
    //
    private String orderNo;
    private String userId;
    private long time;

    private List<OrderItem> items;

    private Order() {
        //
        this.orderNo = UUID.randomUUID().toString();
        items = new ArrayList<OrderItem>();
    }

    private Order(String orderNo) {
        //
        this.orderNo = orderNo;
    }

    public Order(String orderNo, String userId) {
        //
        this();
        this.orderNo = orderNo;
        this.userId = userId;
    }

    public void addItem(OrderItem item) {
        //
        if (!hasItem(item)) {
            items.add(item);
        }
    }

    private boolean hasItem(OrderItem item) {
        //
        if (items.contains(item)) {
            return true;
        } else {
            return false;
        }
    }

    public Money getTotal() {
        //
        Money total = new Money(0);

        for (OrderItem item: items) {
            total = total.add(item.getTotal());
        }

        return total;
    }

    public static Order sample() {
        //
        Order sample = new Order(UUID.randomUUID().toString(), "posco");
        sample.setTime(System.currentTimeMillis());
        sample.setItems(OrderItem.samples());
        return sample;
    }

    public static void main(String[] args) {
        //
        System.out.println((new Gson()).toJson(Order.sample()));
    }
}
