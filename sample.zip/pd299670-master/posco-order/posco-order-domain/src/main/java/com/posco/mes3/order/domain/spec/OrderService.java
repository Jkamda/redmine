package com.posco.mes3.order.domain.spec;

import com.posco.mes3.order.domain.entity.Order;

import java.util.List;

public interface OrderService {
    //
    String registerOrder(Order order);
    Order findOrder(String orderNo);
    List<Order> findOrdersByUserId(String userId);
    List<Order> findAll();
}
