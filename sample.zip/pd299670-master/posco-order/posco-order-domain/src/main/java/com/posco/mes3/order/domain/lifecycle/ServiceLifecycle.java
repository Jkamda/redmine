package com.posco.mes3.order.domain.lifecycle;

import com.posco.mes3.order.domain.spec.OrderService;

public interface ServiceLifecycle {
    //
    OrderService requestOrderService();
}
