package com.posco.mes3.order.domain.lifecycle;

import com.posco.mes3.order.domain.store.OrderStore;

public interface StoreLifecycle {
    //
    OrderStore requestOrderStore();
}
