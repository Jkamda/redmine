package com.posco.mes3.order.domain.entity;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class OrderedProduct {
    //
    private String productNo;
    private String productName;
    private Money salePrice;

    public OrderedProduct(String productNo, String productName, Money salePrice) {
        //
        this.productNo = productNo;
        this.productName = productName;
        this.salePrice = salePrice;
    }

    public static OrderedProduct sample() {
        //
        return new OrderedProduct("1234", "MacBook Pro", new Money(2500000));
    }
}
