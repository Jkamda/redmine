package com.posco.mes3.order.domain.store;

import com.posco.mes3.order.domain.entity.Order;

import java.util.List;

public interface OrderStore {
    //
    void createOrder(Order order);
    Order retrieve(String orderNo);
    List<Order> retrieveAllByUserId(String userId);
	List<Order> retrieveAll();
}
