package com.posco.mes3.order.domain.entity;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
public class OrderItem {
    //
    private OrderedProduct product;
    private int price;
    private int quantity;

    public OrderItem(OrderedProduct product, int quantity) {
        //
        this.product = product;
        this.price = product.getSalePrice().getValue();
        this.quantity = quantity;
    }

    public Money getTotal() {
        //
        return new Money(price * quantity);
    }

    public static List<OrderItem> samples() {
        //
        List<OrderItem> samples = new ArrayList<OrderItem>();
        samples.add(OrderItem.sample());
        return samples;
    }

    public static OrderItem sample() {
        //
        OrderedProduct sampleProduct = OrderedProduct.sample();
        OrderItem sample = new OrderItem(sampleProduct, 2);
        return sample;
    }

}

