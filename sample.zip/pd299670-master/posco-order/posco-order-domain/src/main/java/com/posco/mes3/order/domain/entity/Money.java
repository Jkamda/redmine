package com.posco.mes3.order.domain.entity;

import lombok.NoArgsConstructor;

@NoArgsConstructor
public class Money {

    private int value;

    public Money(int value) {
        //
        this.value = value;
    }

    public Money add(Money money) {
        return new Money(this.value + money.getValue());
    }

    public boolean isGraterThan(Money money) {
        return getValue()  > money.getValue();
    }

    public boolean isLessThan(Money money) {
        return getValue() < money.getValue();
    }

    public boolean equals(Money money) {
        return money.getValue() == getValue();
    }

    public int getValue() {
        //
        return value;
    }
}